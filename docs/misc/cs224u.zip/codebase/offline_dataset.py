import argparse
import itertools
import json
import math
import os
import pathlib
import random
import re
import sys

import flax
import jax
import jax.numpy as jnp
import numpy as np
import openai
import optax
import pinecone

from dotenv import load_dotenv
from flax.training import train_state
from transformers import (
    FlaxAutoModel,
    FlaxAutoModelForCausalLM,
    AutoTokenizer,
)
from tqdm import tqdm

import squad_eval
from data import get_dataset, icl_openqa_prompt, zeroshot_feedback_prompt

load_dotenv()
PINECONE_KEY = os.getenv('PINECONE_API_KEY')
PINECONE_ENV = os.getenv('PINECONE_ENVIRONMENT')
OPENAI_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_ORG = os.getenv('OPENAI_ORG')
pinecone.init(api_key=PINECONE_KEY, environment=PINECONE_ENV)
openai.organization = OPENAI_ORG
openai.api_key = OPENAI_KEY


def random_seed(seed=42, rank=0):
    np.random.seed(seed + rank)
    random.seed(seed + rank)


def parse_args(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--batch-size", type=int, default=1024, help="Global batch size"
    )
    parser.add_argument(
        "--pretrained",
        default='',
        type=str,
        help="Use a pretrained retriever with specified tag or file path.",
    )
    parser.add_argument(
        "--seed", type=int, default=0, help="Default random seed."
    )
    parser.add_argument(
        "--dataset",
        choices=["openwebtext", "wiki18", "squad", "triviaqa"],
        default="squad",
        help="Dataset to index."
    )
    parser.add_argument(
        "--max-length", type=int, default=256, help="Maximum length of document sequences."
    )
    parser.add_argument(
        "--top-k", type=int, default=10, help="Number of documents to retrieve."
    )
    parser.add_argument(
        "--queries", type=int, default=1000, help="Number of queries to evaluate."
    )
    parser.add_argument(
        "--samples-per-query", type=int, default=10, help="Number of samples per query."
    )
    parser.add_argument(
        "--gpt",
        choices=["text-ada-001", "text-babbage-001", "text-curie-001", "text-davinci-003"],
        default="text-ada-001",
        help="GPT-3 model to use for zero-shot feedback.",
    )
    parser.add_argument(
        "--output", type=str, default="results.jsonl", help="Output file."
    )

    args = parser.parse_args(args)
    return args


@jax.jit
def encode_queries(state, input_ids, attention_mask):
    output = state.apply_fn(
        input_ids,
        attention_mask,
        params=state.params,
    ).last_hidden_state

    # average pool
    last_hidden = jnp.where(attention_mask[..., None] == 0, 0, output)
    return last_hidden.sum(axis=1) / attention_mask.sum(axis=1)[..., None]


def pairwise_combinations(x):
    idx = np.stack(np.triu_indices(len(x), k=1), axis=-1)
    return x[idx]


def main(args):
    args = parse_args(args)
    random_seed(args.seed, 0)
    world_size = jax.device_count()

    retriever = FlaxAutoModel.from_pretrained('intfloat/e5-small', from_pt=True)
    retriever.params = retriever.to_bf16(retriever.params)
    ret_tokenizer = AutoTokenizer.from_pretrained('intfloat/e5-small', use_fast=True)
    # TODO: load this from a pretrained checkpoint

    _, dataset = get_dataset(
        args.dataset,
        doc_length=args.max_length,
        split='train',
        train_docs=None,
        retrieval_docs=args.queries,
        owt_bin=None,
    )
    print(f'Loaded {len(dataset):,} examples from {args.dataset}')

    # Setup index
    assert args.dataset in pinecone.list_indexes(), f'Index {args.dataset} does not exist.'
    pc_index = pinecone.Index(args.dataset, pool_threads=world_size * 6)
    print(pc_index.describe_index_stats())

    # Embed the queries
    p_encode_batch = jax.pmap(
        encode_queries,
        axis_name='batch',
    )
    state = train_state.TrainState.create(
        apply_fn=retriever.__call__,
        params=retriever.params,
        tx=optax.adamw(0, b1=0.9, b2=0.95, weight_decay=0.01),
    )
    state = flax.jax_utils.replicate(state)

    query_embeddings = []
    total_batches = math.ceil(len(dataset) / args.batch_size)
    queries = dataset['question']  # TODO: expensive for big datasets
    for i in tqdm(range(total_batches), desc='Embedding queries'):
        batch_q = queries[i * args.batch_size : (i + 1) * args.batch_size]
        batch_q = [f'query: {q}' for q in batch_q] # TODO: make E5 prepro configurable
        tok_q = ret_tokenizer(
            batch_q,
            padding='max_length',
            truncation=True,
            max_length=args.max_length,
            return_tensors='np',
        )
        input_ids = tok_q.input_ids
        attention_mask = tok_q.attention_mask

        input_batch_size = input_ids.shape[0]
        ragged = input_batch_size % world_size
        if ragged:
            padding = np.zeros([world_size - ragged, *input_ids.shape[1:]], input_ids.dtype)
            input_ids = np.concatenate([input_ids, padding], axis=0)
            attention_mask = np.concatenate([attention_mask, padding], axis=0)
            print(f'Warning: padding to nearest multiple of {world_size} '
                  f'(input: {input_batch_size}, padded: {input_ids.shape[0]})')
        batch_size_per_device = input_ids.shape[0] // world_size
        shape_prefix = (world_size, batch_size_per_device)
        input_ids = input_ids.reshape(shape_prefix + input_ids.shape[1:])
        attention_mask = attention_mask.reshape(shape_prefix + attention_mask.shape[1:])

        embeddings = p_encode_batch(state, input_ids, attention_mask)
        embeddings = embeddings.reshape(-1, embeddings.shape[-1])
        if ragged:
            embeddings = embeddings[:input_batch_size]
        query_embeddings.append(jax.device_get(embeddings))

    # Perform retrieval
    query_embeddings = np.concatenate(query_embeddings, axis=0)
    topk = []
    query_batch_size = 100
    total_query_batches = math.ceil(len(query_embeddings) / query_batch_size)
    for i in tqdm(range(total_query_batches), desc=f'Retrieving top-{args.top_k}'):
        batch_q = query_embeddings[i * query_batch_size : (i + 1) * query_batch_size]
        index_results = pc_index.query(
            queries=batch_q.tolist(),
            top_k=args.top_k,
            include_metadata=True).results
        topk.extend([[m.metadata['text'] for m in r.matches] for r in index_results])

    topk = np.array(topk)

    # Generate pairs
    idx_pairs = pairwise_combinations(np.arange(args.top_k))
    dataset_queries = []
    dataset_context1 = []
    dataset_context2 = []
    for i, query in enumerate(queries):
        pairs = []
        docs = topk[i]
        idx = np.random.choice(
            len(idx_pairs),
            size=args.samples_per_query,
            replace=False,
        )
        sampled_pairs = docs[idx_pairs[idx]]
        c1, c2 = zip(*sampled_pairs)
        dataset_queries.extend([query] * args.samples_per_query)
        dataset_context1.extend(c1)
        dataset_context2.extend(c2)

    # Build prompts
    prompts = [zeroshot_feedback_prompt(q, c1, c2) for q, c1, c2 in \
                zip(dataset_queries, dataset_context1, dataset_context2)]

    # Ask GPT-3 for feedback
    reader_results = []
    reader_batch_size = 20
    total_reader_batches = math.ceil(len(prompts) / reader_batch_size)

    # Cry counter
    price_per_token = {
        'text-ada-001': 0.0004 / 1000,
        'text-babbage-001': 0.0005 / 1000,
        'text-curie-001': 0.002 / 1000,
        'text-davinci-003': 0.02 / 1000,
    }
    total_cost = 0
    total_tokens = 0
    for i in tqdm(range(total_reader_batches), desc='Collecting GPT-3 feedback'):
        batch_prompt = prompts[i * reader_batch_size : (i + 1) * reader_batch_size]
        completion = openai.Completion.create(
            model=args.gpt,
            prompt=batch_prompt,
            max_tokens=2,
            temperature=0,  # deterministically take top token
        )
        tokens_used = completion.usage.total_tokens
        total_tokens += tokens_used
        total_cost += tokens_used * price_per_token[args.gpt]
        reader_results.extend([c.text for c in completion.choices])
    preference_labels = [re.findall(r'A|B', r)[0] for r in reader_results]
    print(f'Total tokens: {total_tokens:,}\nEstimated GPT-3 cost: ${total_cost:,.2f}')

    # Dump feedback dataset to disk
    output_path = pathlib.Path(os.path.expanduser(args.output))
    if not output_path.parent.exists():
        output_path.parent.mkdir(parents=True)

    with open(output_path, 'w') as f:
        data_iter = list(zip(
            dataset_queries,
            dataset_context1,
            dataset_context2,
            preference_labels,
        ))
        for q, c1, c2, l in tqdm(data_iter, desc='Writing dataset'):
            label = 1 if l == 'A' else 2
            json.dump({
                'query': q,
                'context1': c1,
                'context2': c2,
                'label': label,
            }, f)
            f.write('\n')

    import pdb; pdb.set_trace()


if __name__ == "__main__":
    main(sys.argv[1:])
