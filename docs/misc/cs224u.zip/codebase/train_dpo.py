"""Direct Policy Optimization (DPO)."""

import argparse
import itertools
import math
import os
import pathlib
import random
import sys
import time

import distrax
import flax
import jax
import jax.numpy as jnp
import numpy as np
import optax
import pinecone

from datasets import load_dataset
from dotenv import load_dotenv
from flax.training import checkpoints, train_state
from transformers import (
    FlaxAutoModel,
    FlaxAutoModelForCausalLM,
    AutoTokenizer,
)


load_dotenv()
PINECONE_KEY = os.getenv('PINECONE_API_KEY')
PINECONE_ENV = os.getenv('PINECONE_ENVIRONMENT')
pinecone.init(api_key=PINECONE_KEY, environment=PINECONE_ENV)


class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def random_seed(seed=42, rank=0):
    np.random.seed(seed + rank)
    random.seed(seed + rank)


def parse_args(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--batch-size", type=int, default=64, help="Global batch size"
    )
    parser.add_argument(
        "--pretrained",
        default='',
        type=str,
        help="Use a pretrained retriever with specified tag or file path.",
    )
    parser.add_argument(
        "--dataset", type=str, default=None, help="Path to preference dataset.jsonl"
    )
    parser.add_argument(
        "--seed", type=int, default=0, help="Default random seed."
    )
    parser.add_argument(
        "--max-length", type=int, default=256, help="Maximum length of document sequences."
    )
    parser.add_argument(
        "--epochs", type=int, default=10, help="Number of epochs to train."
    )
    parser.add_argument(
        "--beta", type=float, default=1e3, help="Inverse temperature."
    )
    parser.add_argument(
        '--ckpt-dir', type=str, default=None, help='Path to save checkpoints.'
    )

    args = parser.parse_args(args)
    return args


@jax.jit
def average_pool(last_hidden_state, attention_mask):
    last_hidden = jnp.where(attention_mask[..., None] == 0, 0, last_hidden_state)
    return last_hidden.sum(axis=1) / attention_mask.sum(axis=1)[..., None]


@jax.jit
def encode_text(state, params, input_ids, attention_mask):
    output = state.apply_fn(
        input_ids,
        attention_mask,
        params=params,
    ).last_hidden_state
    embed = average_pool(output, attention_mask)
    return embed / jnp.linalg.norm(embed, axis=-1, keepdims=True)


@jax.jit
def train_step(
    pi,
    ref,
    x_ids,
    x_attn,
    yw_ids,
    yw_attn,
    yl_ids,
    yl_attn,
    beta=1,
):

    def loss_fn(params):
        # Encode
        pi_x = encode_text(pi, params, x_ids, x_attn)
        pi_yw = encode_text(pi, params, yw_ids, yw_attn)
        pi_yl = encode_text(pi, params, yl_ids, yl_attn)

        ref_x = encode_text(ref, ref.params, x_ids, x_attn)
        ref_yw = encode_text(ref, ref.params, yw_ids, yw_attn)
        ref_yl = encode_text(ref, ref.params, yl_ids, yl_attn)

        # Compute scores
        pi_yw_logp = jnp.sum(pi_x * pi_yw, axis=-1)
        pi_yl_logp = jnp.sum(pi_x * pi_yl, axis=-1)
        ref_yw_logp = jnp.sum(ref_x * ref_yw, axis=-1)
        ref_yl_logp = jnp.sum(ref_x * ref_yl, axis=-1)

        pi_logratios = pi_yw_logp - pi_yl_logp
        ref_logratios = ref_yw_logp - ref_yl_logp

        # Compute loss
        # NOTE: Rewards are implicitly computed in the gradient
        loss = -jax.nn.log_sigmoid(beta * (pi_logratios - ref_logratios))
        scores = {
            "pi_yw_logp": pi_yw_logp,
            "pi_yl_logp": pi_yl_logp,
            "ref_yw_logp": ref_yw_logp,
            "ref_yl_logp": ref_yl_logp,
        }
        return jnp.mean(loss), scores

    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    loss, grads = grad_fn(pi.params)
    pi = pi.apply_gradients(grads=grads)
    return pi, loss[0], loss[1]


def create_learning_rate_fn(config):
    warmup_fn = optax.linear_schedule(
        init_value=0.0,
        end_value=config.learning_rate,
        transition_steps=config.lr_warmup_steps,
    )
    num_batches = config.train_num_samples // config.batch_size
    train_steps = config.epochs * num_batches
    if config.lr_cosine_decay:
        decay_steps = train_steps - config.lr_warmup_steps
        opt_fn = optax.cosine_decay_schedule(
            init_value=config.learning_rate, decay_steps=decay_steps
        )
    else:
        opt_fn = optax.constant_schedule(config.learning_rate)

    learning_rate_fn = optax.join_schedules(
        schedules=[warmup_fn, opt_fn], boundaries=[config.lr_warmup_steps]
    )
    return learning_rate_fn


def main(args):
    args = parse_args(args)
    random_seed(args.seed, 0)
    world_size = jax.device_count()

    assert args.ckpt_dir is not None, 'Checkpoint directory must be specified.'
    ckpt_dir = pathlib.Path(os.path.expanduser(args.ckpt_dir))
    if not ckpt_dir.exists():
        ckpt_dir.mkdir(parents=True)

    # Load offline preference dataset
    data_path = os.path.expanduser(args.dataset)
    train_dataset = load_dataset('json', split='train', data_files=[data_path])
    train_dataset = train_dataset.shuffle(seed=args.seed)
    n_examples = (len(train_dataset) // args.batch_size) * args.batch_size
    train_dataset = train_dataset.select(range(n_examples))
    print(f'Loaded {len(train_dataset):,} feedback pairs from {data_path}')

    # Load model parameters
    # TODO: load from args.pretrained if specified
    retriever = FlaxAutoModel.from_pretrained('intfloat/e5-small', from_pt=True)
    retriever.params = retriever.to_bf16(retriever.params)
    policy_state = train_state.TrainState.create(
        apply_fn=retriever.__call__,
        params=retriever.params,
        tx=optax.adam(3e-5),
    )
    reference = FlaxAutoModel.from_pretrained('intfloat/e5-small', from_pt=True)
    reference.params = reference.to_bf16(reference.params)
    ref_state = train_state.TrainState.create(
        apply_fn=reference.__call__,
        params=reference.params,
        tx=optax.adamw(0, b1=0.9, b2=0.95, weight_decay=0.),
    )

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained('intfloat/e5-small', use_fast=True)

    # DPO
    total_num_batches = math.ceil(len(train_dataset) / args.batch_size)
    sample_digits = math.ceil(math.log(len(train_dataset) + 1, 10))
    for epoch in range(args.epochs):
        batch_time_m = AverageMeter()
        end = time.time()
        num_samples = 0

        for i in range(total_num_batches):
            batch = train_dataset[i * args.batch_size : (i + 1) * args.batch_size]
            num_samples += len(batch['query'])

            batch_q = tokenizer(
                [f'query: {q}' for q in batch['query']],
                padding='max_length',
                truncation=True,
                max_length=args.max_length,
                return_tensors='jax',
            )
            batch_c1 = tokenizer(
                [f'passage: {c1}' for c1 in batch['context1']],
                padding='max_length',
                truncation=True,
                max_length=args.max_length,
                return_tensors='jax',
            )
            batch_c2 = tokenizer(
                [f'passage: {c2}' for c2 in batch['context2']],
                padding='max_length',
                truncation=True,
                max_length=args.max_length,
                return_tensors='jax',
            )

            # Construct the win and lose passages
            labels = jnp.array(batch['label']) - 1  # 0 for c1, 1 for c2
            y_w_ids = jnp.where(labels[:, None] == 0, batch_c1.input_ids, batch_c2.input_ids)
            y_w_attn_mask = jnp.where(labels[:, None] == 0, batch_c1.attention_mask, batch_c2.attention_mask)
            y_l_ids = jnp.where(labels[:, None] == 1, batch_c1.input_ids, batch_c2.input_ids)
            y_l_attn_mask = jnp.where(labels[:, None] == 1, batch_c1.attention_mask, batch_c2.attention_mask)

            policy_state, dpo_loss, scores = train_step(
                policy_state,
                ref_state,
                batch_q.input_ids,
                batch_q.attention_mask,
                y_w_ids,
                y_w_attn_mask,
                y_l_ids,
                y_l_attn_mask,
                beta=args.beta,
            )
            batch_time_m.update(time.time() - end)
            end = time.time()

            # Logging
            samples_per_second = args.batch_size * world_size / batch_time_m.val
            samples_per_second_per_gpu = args.batch_size / batch_time_m.val
            percent_complete = num_samples / len(train_dataset) * 100
            lr = jnp.array(0) #jax.tree_map(lambda x: x[0], learning_rate_fn(state.step))
            print(
                f"Train Epoch: {epoch} [{num_samples:>{sample_digits}}/{len(train_dataset)} ({percent_complete:.0f}%)] "
                f"Batch (t): {batch_time_m.avg:.3f}, {samples_per_second:#g}/s, {samples_per_second_per_gpu:#g}/s/xpu "
                f"LR: {lr.item():5f} Loss: {dpo_loss.item():.4f}"
            )

        checkpoints.save_checkpoint(
            ckpt_dir=ckpt_dir,
            step=epoch,
            target=policy_state.params,
            overwrite=True,
            keep=args.epochs,
        )


if __name__ == "__main__":
    main(sys.argv[1:])
