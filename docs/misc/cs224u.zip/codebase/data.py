import os

import numpy as np
from datasets import load_dataset, concatenate_datasets


class OpenWebText(object):

    def __init__(self, bin_path, sequence_length, index_list=None):
        self.path = bin_path
        self.data = np.memmap(os.path.expanduser(bin_path), dtype=np.uint16, mode='r')
        self.block_size = sequence_length

        self.index_list = index_list
        if index_list is not None:
            self.size = len(index_list)
        else:
            self.size = len(self.data) // self.block_size

    def get_passage(self, idx):
        start = idx * self.block_size
        end = start + self.block_size
        return self.data[start:end]

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            start = idx.start or 0
            stop = min(idx.stop, self.size) or self.size
            step = idx.step or 1
            if self.index_list is None:
                passage_ids = [i for i in range(start, stop, step)]
            else:
                passage_ids = [self.index_list[i] for i in range(start, stop, step)]
            passages = np.stack([self.get_passage(i) for i in passage_ids])
            return {'text': passages, 'id': passage_ids}
        else:
            passage_id = idx if self.index_list is None else self.index_list[idx]
            return {'id': passage_id, 'text': self.get_passage(passage_id)}

    def __len__(self):
        return self.size

    def select(self, idx):
        return OpenWebText(self.path, self.block_size, index_list=idx)


def icl_openqa_prompt(demos, query, context):
    prompt = []
    for icl_q, icl_c, icl_a in demos:
        demo_prompt = f"Knowledge: {icl_c}\nQuestion: {icl_q}\nAnswer: {icl_a}"
        prompt.append(demo_prompt)
    # Due to a quirk with GPT-2 generation, there should be no space after the prompt
    prompt.append(f"Knowledge: {context}\nQuestion: {query}\nAnswer:")
    return '\n\n'.join(prompt)


def zeroshot_feedback_prompt(query, context1, context2):
    prompt = f"Passage A: {context1}\n\n" \
             f"Passage B: {context2}\n\n" \
             f"Query: {query}\n" \
             f"Question: Which passage is more relevant for answering the Query? " \
             "Make sure you have the right answer. Choices: A or B.\nAnswer:"
    return prompt


def get_dataset(
    name,
    doc_length=256,
    split='train',
    train_docs=None,
    retrieval_docs=None,
    owt_bin=None,
    dedup=False,
):
    if name == "openwebtext":
        assert owt_bin is not None, "Must specify --owt_bin for OpenWebText dataset."
        ds = OpenWebText(owt_bin, doc_length)
    elif name == "wiki18":
        ds = load_dataset(
            'wiki_dpr',
            'psgs_w100.multiset.compressed.no_embeddings',
            split=split,
        )
        ds.drop_index('embeddings')
    elif name == 'trivia_qa':
        def _rename(x):
            x['answer']['text'] = x['answer'].pop('aliases')
            return x
        ds = load_dataset(
            'trivia_qa',
            'rc.wikipedia.nocontext',
            split=split,
        )
        ds = ds.map(_rename)
        ds = ds.rename_column('answer', 'answers')
    elif name == 'nq':
        def _rename(x):
            x['answer'] = {
                'text': x['answer']
            }
            return x
        ds = load_dataset(
            'nq_open',
            split=split,
        )
        ds = ds.map(_rename)
        ds = ds.rename_column('answer', 'answers')
    elif name == 'dynabench':
        ds = load_dataset(
            'dynabench/qa',
            'dynabench.qa.r1.droberta',
            split=split,
        )
    elif name == "squad":
        if split == 'all':
            ds = concatenate_datasets([
                load_dataset(
                    'squad',
                    split=split,
                ),
                load_dataset(
                    'squad',
                    split='validation',
                ),
            ])
        else:
            ds = load_dataset(
                'squad',
                split=split,
            )
        ds = ds.rename_column('context', 'text')

        if dedup:
            passage_to_idx = {}
            for i, ex in enumerate(ds):
                if ex['text'] not in passage_to_idx:
                    passage_to_idx[ex['text']] = [i]
                else:
                    passage_to_idx[ex['text']].append(i)
            ds = ds.select([v[0] for v in passage_to_idx.values()])
    elif name == "triviaqa":
        ds = load_dataset(
            'trivia_qa',
            'rc.wikipedia.nocontext',
            split=split)
        raise NotImplementedError("TriviaQA not yet supported.")
    else:
        raise ValueError(f"Unknown dataset: {name}")

    sample_docs = retrieval_docs is not None or train_docs is not None
    if retrieval_docs is None:
        retrieval_docs = len(ds)
    if train_docs is None:
        train_docs = len(ds) - retrieval_docs

    if sample_docs:
        assert 0 <= train_docs + retrieval_docs <= len(ds)
        n_docs = train_docs + retrieval_docs
        sampled_idx = np.random.choice(len(ds), n_docs, replace=False)
        train_idx = sampled_idx[:train_docs]
        retrieval_idx = sampled_idx[train_docs:]

        train_ds = ds.select(train_idx)
        retrieval_ds = ds.select(retrieval_idx)
        return train_ds, retrieval_ds

    return None, ds
