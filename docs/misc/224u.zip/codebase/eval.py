import argparse
import itertools
import math
import os
import random
import sys

import flax
import jax
import jax.numpy as jnp
import numpy as np
import openai
import optax
import pinecone
import tiktoken

from dotenv import load_dotenv
from flax.training import checkpoints, train_state
from transformers import (
    FlaxAutoModel,
    FlaxAutoModelForCausalLM,
    AutoTokenizer,
)
from tqdm import tqdm

import squad_eval
from data import get_dataset, icl_openqa_prompt

load_dotenv()
PINECONE_KEY = os.getenv('PINECONE_API_KEY')
PINECONE_ENV = os.getenv('PINECONE_ENVIRONMENT')
OPENAI_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_ORG = os.getenv('OPENAI_ORG')
pinecone.init(api_key=PINECONE_KEY, environment=PINECONE_ENV)
openai.organization = OPENAI_ORG
openai.api_key = OPENAI_KEY


def random_seed(seed=42, rank=0):
    np.random.seed(seed + rank)
    random.seed(seed + rank)


def parse_args(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--batch-size", type=int, default=1024, help="Global batch size"
    )
    parser.add_argument(
        "--pretrained",
        default=None,
        type=str,
        help="Use a pretrained retriever with specified tag or file path.",
    )
    parser.add_argument(
        "--seed", type=int, default=0, help="Default random seed."
    )
    parser.add_argument(
        "--dataset",
        choices=["openwebtext", "wiki18", "squad", "trivia_qa", "nq", "dynabench"],
        default="squad",
        help="Dataset to index."
    )
    parser.add_argument(
        "--owt-bin", type=str, default=None, help="Path to OpenWebText bin file."
    )
    parser.add_argument(
        "--max-length", type=int, default=256, help="Maximum length of document sequences."
    )
    parser.add_argument(
        "--top-k", type=int, default=5, help="Number of documents to retrieve."
    )
    parser.add_argument(
        "--gpt",
        choices=["text-ada-001", "text-babbage-001", "text-curie-001", "text-davinci-003"],
        default="text-ada-001",
        help="GPT-3 model to use for zero-shot feedback.",
    )
    parser.add_argument(
        "--index-name", type=str, default=None, help="Name of the Pinecone index."
    )

    args = parser.parse_args(args)
    return args


@jax.jit
def encode_queries(state, input_ids, attention_mask):
    output = state.apply_fn(
        input_ids,
        attention_mask,
        params=state.params,
    ).last_hidden_state

    # average pool
    last_hidden = jnp.where(attention_mask[..., None] == 0, 0, output)
    return last_hidden.sum(axis=1) / attention_mask.sum(axis=1)[..., None]


def main(args):
    args = parse_args(args)
    random_seed(args.seed, 0)
    world_size = jax.device_count()

    retriever = FlaxAutoModel.from_pretrained('intfloat/e5-small', from_pt=True)
    if args.pretrained is not None:
        pretrained_params = checkpoints.restore_checkpoint(
            ckpt_dir=args.pretrained,
            target=None,
        )
        retriever.params = pretrained_params
    retriever.params = retriever.to_bf16(retriever.params)
    ret_tokenizer = AutoTokenizer.from_pretrained('intfloat/e5-small', use_fast=True)

    reader = FlaxAutoModelForCausalLM.from_pretrained('EleutherAI/gpt-neo-125m')
    reader.params = reader.to_bf16(reader.params)
    reader_tokenizer = AutoTokenizer.from_pretrained('EleutherAI/gpt-neo-125m', use_fast=True)

    _, dataset = get_dataset(
        args.dataset,
        doc_length=args.max_length,
        split='validation',
        train_docs=None,
        retrieval_docs=None,
        owt_bin=args.owt_bin,
    )
    # dataset = dataset.select(range(100)) # HACK: for testing
    print(f'Loaded {len(dataset):,} examples from {args.dataset}')

    # Setup index
    index_name = args.index_name if args.index_name is not None else args.dataset
    assert index_name in pinecone.list_indexes(), f'Index {index_name} does not exist.'
    pc_index = pinecone.Index(index_name, pool_threads=world_size * 6)
    print(pc_index.describe_index_stats())

    # TODO: the following is very SQuAD specific
    # Setup in-context learning prompt
    icl_dataset, _ = get_dataset(
        'squad',
        doc_length=args.max_length,
        split='train',
        train_docs=3,  # 3-shot in-context learning
        retrieval_docs=0,
        owt_bin=args.owt_bin,
    )
    icl_questions, icl_contexts, icl_answers = [], [], []
    for i in range(len(icl_dataset)):
        icl_questions.append(icl_dataset[i]['question'])
        icl_contexts.append(icl_dataset[i]['text'])
        icl_answers.append(icl_dataset[i]['answers']['text'][0])
    icl_demos = list(zip(icl_questions, icl_contexts, icl_answers))

    # Embed the queries
    p_encode_batch = jax.pmap(
        encode_queries,
        axis_name='batch',
    )
    state = train_state.TrainState.create(
        apply_fn=retriever.__call__,
        params=retriever.params,
        tx=optax.adamw(0, b1=0.9, b2=0.95, weight_decay=0.01),
    )
    state = flax.jax_utils.replicate(state)

    query_embeddings = []
    total_batches = math.ceil(len(dataset) / args.batch_size)
    queries = dataset['question']  # TODO: expensive for big datasets
    for i in tqdm(range(total_batches), desc='Embedding queries'):
        batch_q = queries[i * args.batch_size : (i + 1) * args.batch_size]
        batch_q = [f'query: {q}' for q in batch_q] # TODO: make E5 prepro configurable
        tok_q = ret_tokenizer(
            batch_q,
            padding='max_length',
            truncation=True,
            max_length=args.max_length,
            return_tensors='np',
        )
        input_ids = tok_q.input_ids
        attention_mask = tok_q.attention_mask

        input_batch_size = input_ids.shape[0]
        ragged = input_batch_size % world_size
        if ragged:
            padding = np.zeros([world_size - ragged, *input_ids.shape[1:]], input_ids.dtype)
            input_ids = np.concatenate([input_ids, padding], axis=0)
            attention_mask = np.concatenate([attention_mask, padding], axis=0)
            print(f'Warning: padding to nearest multiple of {world_size} '
                  f'(input: {input_batch_size}, padded: {input_ids.shape[0]})')
        batch_size_per_device = input_ids.shape[0] // world_size
        shape_prefix = (world_size, batch_size_per_device)
        input_ids = input_ids.reshape(shape_prefix + input_ids.shape[1:])
        attention_mask = attention_mask.reshape(shape_prefix + attention_mask.shape[1:])

        embeddings = p_encode_batch(state, input_ids, attention_mask)
        embeddings = embeddings.reshape(-1, embeddings.shape[-1])
        if ragged:
            embeddings = embeddings[:input_batch_size]
        query_embeddings.append(jax.device_get(embeddings))

    # Perform retrieval
    query_embeddings = np.concatenate(query_embeddings, axis=0)
    topk = []
    query_batch_size = 100
    total_query_batches = math.ceil(len(query_embeddings) / query_batch_size)
    for i in tqdm(range(total_query_batches), desc=f'Retrieving top-{args.top_k}'):
        batch_q = query_embeddings[i * query_batch_size : (i + 1) * query_batch_size]
        index_results = pc_index.query(
            queries=batch_q.tolist(),
            top_k=args.top_k,
            include_metadata=True).results
        topk.extend([[m.metadata['text'] for m in r.matches] for r in index_results])

    # Build prompts and run reader
    prompts = [icl_openqa_prompt(icl_demos, q, ' '.join(topk[i])) for i, q in enumerate(queries)]
    enc = tiktoken.encoding_for_model(args.gpt)
    prompt_lens = [len(enc.encode(p)) > 2020 for p in prompts]
    skipped = [i for i, l in enumerate(prompt_lens) if l]
    if len(skipped) > 0:
        print(f'Skipped {len(skipped)} prompts due to length > 2020')

    # Drop prompts that are too long (avoid OpenAI failure)
    prompts = [p for i, p in enumerate(prompts) if i not in skipped]

    reader_results = []
    reader_batch_size = 20
    total_reader_batches = math.ceil(len(prompts) / reader_batch_size)
    for i in tqdm(range(total_reader_batches), desc='Generating answers'):
        batch_prompt = prompts[i * reader_batch_size : (i + 1) * reader_batch_size]
        completion = openai.Completion.create(
            model=args.gpt,
            prompt=batch_prompt,
            max_tokens=20,
            temperature=0.1,
        ).choices
        reader_results.extend([c.text for c in completion])

    # Compute metrics
    if args.dataset in ['squad', 'trivia_qa', 'nq', 'dynabench']:
        ground_truths = [ex['text'] for ex in dataset['answers']]
        # Drop ground truths where prompts failed
        ground_truths = [gt for i, gt in enumerate(ground_truths) if i not in skipped]

        answers = [a.strip().split('\n')[0] for a in reader_results]
        exact_match, f1 = 0, 0
        for prediction, gt in zip(answers, ground_truths):
            exact_match += squad_eval.metric_max_over_ground_truths(
                    squad_eval.exact_match_score, prediction, gt)
            f1 += squad_eval.metric_max_over_ground_truths(
                squad_eval.f1_score, prediction, gt)
        exact_match /= len(answers)
        f1 /= len(answers)
        print(f'Exact match: {100. * exact_match:.4f}, F1: {100. * f1:.4f}')
        import pdb; pdb.set_trace()
    elif args.dataset == 'openwebtext':
        import pdb; pdb.set_trace()

    import pdb; pdb.set_trace()


if __name__ == "__main__":
    main(sys.argv[1:])
