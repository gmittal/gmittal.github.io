import argparse
import itertools
import math
import os
import random
import sys

import flax
import jax
import jax.numpy as jnp
import numpy as np
import optax
import pinecone

from dotenv import load_dotenv
from flax.training import checkpoints, train_state
from transformers import FlaxAutoModel, AutoTokenizer
from tqdm import tqdm

from data import get_dataset

load_dotenv()
PINECONE_KEY = os.getenv('PINECONE_API_KEY')
PINECONE_ENV = os.getenv('PINECONE_ENVIRONMENT')
pinecone.init(api_key=PINECONE_KEY, environment=PINECONE_ENV)


def random_seed(seed=42, rank=0):
    np.random.seed(seed + rank)
    random.seed(seed + rank)


def parse_args(args):
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--batch-size", type=int, default=1024, help="Global batch size"
    )
    parser.add_argument(
        "--pretrained",
        default=None,
        type=str,
        help="Use a pretrained retriever with specified tag or file path.",
    )
    parser.add_argument(
        "--seed", type=int, default=0, help="Default random seed."
    )
    parser.add_argument(
        "--dataset",
        choices=["openwebtext", "wiki18", "squad"],
        default="squad",
        help="Dataset to index."
    )
    parser.add_argument(
        "--owt-bin", type=str, default=None, help="Path to OpenWebText bin file."
    )
    parser.add_argument(
        "--max-length", type=int, default=256, help="Maximum length of document sequences."
    )
    parser.add_argument(
        "--train-docs", type=int, default=None, help="Maximum number of documents to train."
    )
    parser.add_argument(
        "--retrieval-docs", type=int, default=None, help="Maximum number of documents to index."
    )
    parser.add_argument(
        "--index-name", type=str, default=None, help="Index name to use."
    )

    args = parser.parse_args(args)
    return args


def chunks(iterable, batch_size=100):
    """A helper function to break an iterable into chunks of size batch_size."""
    it = iter(iterable)
    chunk = tuple(itertools.islice(it, batch_size))
    while chunk:
        yield chunk
        chunk = tuple(itertools.islice(it, batch_size))


@jax.jit
def encode_batch(state, input_ids, attention_mask):
    output = state.apply_fn(
        input_ids,
        attention_mask,
        params=state.params,
    ).last_hidden_state

    # average pool
    last_hidden = jnp.where(attention_mask[..., None] == 0, 0, output)
    return last_hidden.sum(axis=1) / attention_mask.sum(axis=1)[..., None]


def build_index(
    retriever,
    tokenizer,
    dataset_name,
    retrieval_dataset,
    doc_length=256,
    batch_size=1024,
    index_name=None,
):
    if index_name is None:
        index_name = dataset_name

    world_size = jax.device_count()
    dataset = retrieval_dataset

    # Setup index
    if index_name not in pinecone.list_indexes():
        # create the index if it does not exist
        pinecone.create_index(
            index_name,
            dimension=retriever.config.hidden_size,
            metric="cosine"
        )
    pc_index = pinecone.Index(index_name, pool_threads=world_size * 6)
    print(pc_index.describe_index_stats())

    # Compile encoder
    p_encode_batch = jax.pmap(
        encode_batch,
        axis_name='batch',
    )
    tx = optax.adamw(3e-4, b1=0.9, b2=0.95, weight_decay=0.01)
    state = train_state.TrainState.create(
        apply_fn=retriever.__call__,
        params=retriever.params,
        tx=tx,
    )
    state = flax.jax_utils.replicate(state)

    # Encode documents
    results = []  # this is not memory efficient but will do for now...
    ids = []
    total_batches = int(math.ceil(len(dataset) / batch_size))
    for i in tqdm(range(total_batches)):
        batch = dataset[i * batch_size: (i + 1) * batch_size]

        # E5 embeddings expect "passage: " prefix
        # TODO: make this configurable based on retriever type
        batch_text = [f'passage: {text}' for text in batch['text']]

        if dataset_name != "openwebtext":
            passages = tokenizer(
                batch_text,
                truncation=True,
                padding='max_length',
                max_length=doc_length,
                return_tensors='np',
            )
            input_ids = passages.input_ids
            attention_mask = passages.attention_mask
        else:
            print('Check OWT encoding to make sure passage: prefix is appended.')
            import pdb; pdb.set_trace()
            ids.append([str(i) for i in batch['id']])
            input_ids = batch['text'][:, :doc_length]
            attention_mask = np.ones_like(input_ids)

        # Shard global batch across devices
        input_batch_size = input_ids.shape[0]
        ragged = input_batch_size % world_size
        if ragged:
            padding = np.zeros([world_size - ragged, *input_ids.shape[1:]], input_ids.dtype)
            input_ids = np.concatenate([input_ids, padding], axis=0)
            attention_mask = np.concatenate([attention_mask, padding], axis=0)
            print(f'Warning: padding to nearest multiple of {world_size} '
                  f'(input: {input_batch_size}, padded: {input_ids.shape[0]})')
        batch_size_per_device = input_ids.shape[0] // world_size
        shape_prefix = (world_size, batch_size_per_device)
        input_ids = input_ids.reshape(shape_prefix + input_ids.shape[1:])
        attention_mask = attention_mask.reshape(shape_prefix + attention_mask.shape[1:])

        # Encode batch
        embeddings = p_encode_batch(
            state,
            input_ids,
            attention_mask,
        )

        # Unshard and unpad (this is pretty expensive)
        embeddings = embeddings.reshape(-1, retriever.config.hidden_size)
        if ragged:
            embeddings = embeddings[:input_batch_size]
        embeddings = jax.device_get(embeddings)
        results.append(embeddings)

    # Add to index
    with pc_index as index:
        async_results = []
        for i, embeddings in tqdm(enumerate(results), total=len(results)):
            if dataset_name == "openwebtext":
                batch_id = ids[i]
                docs = zip(batch_id, embeddings.tolist())

            else:  # squad, wiki18
                # TODO: check this is correct for the batch!!
                batch = dataset[i * batch_size: (i + 1) * batch_size]
                metadata = [{'text': text} for text in batch['text']]
                docs = zip(batch['id'], embeddings.tolist(), metadata)

            index_bs = 500 if dataset_name == "openwebtext" else 100
            async_results.extend([
                index.upsert(vectors=ids_vectors_chunk, async_req=True)
                for ids_vectors_chunk in chunks(docs, batch_size=index_bs)
            ])

        # Wait for and retrieve responses (this raises in case of error)
        try:
            response = [async_result.get() for async_result in async_results]
            assert sum([r['upserted_count'] for r in response]) == len(dataset)
        except Exception as e:
            print(e)
            import pdb; pdb.set_trace()

    print(pc_index.describe_index_stats())


def main(args):
    args = parse_args(args)
    random_seed(args.seed, 0)

    # Load dataset
    train_docs = None
    retrieval_docs = args.retrieval_docs
    doc_length = args.max_length
    dataset_name = args.dataset
    if retrieval_docs is not None:
        train_docs = args.train_docs if dataset_name == 'openwebtext' else 0

    train_dataset, dataset = get_dataset(
        dataset_name,
        doc_length=doc_length * 2 \
            if dataset_name == 'openwebtext' else doc_length,
        split='train' if dataset_name != 'squad' else 'all',
        train_docs=train_docs,
        retrieval_docs=retrieval_docs,
        owt_bin=args.owt_bin,
        dedup=dataset_name == 'squad',
    )
    if dataset_name == 'openwebtext':
        print('Train examples:', train_dataset.index_list)
        print('Retrieval examples:', dataset.index_list)
    del train_dataset  # unused
    print(f'Loaded {len(dataset):,} retrieval documents from {dataset_name}')

    # Load model parameters
    retriever = FlaxAutoModel.from_pretrained('intfloat/e5-small', from_pt=True)
    if args.pretrained is not None:
        pretrained_params = checkpoints.restore_checkpoint(
            ckpt_dir=args.pretrained,
            target=None,
        )
        retriever.params = pretrained_params
    retriever.params = retriever.to_bf16(retriever.params)
    tokenizer = AutoTokenizer.from_pretrained('intfloat/e5-small', use_fast=True)
    # TODO: load this from a pretrained checkpoint

    # Build index
    build_index(
        retriever,
        tokenizer,
        args.dataset,
        dataset,
        doc_length=args.max_length,
        batch_size=args.batch_size,
        index_name=args.index_name,
    )


if __name__ == "__main__":
    main(sys.argv[1:])
